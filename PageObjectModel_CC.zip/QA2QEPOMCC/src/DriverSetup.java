import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class DriverSetup {
	public WebDriver driver;
	

	@BeforeTest
	public void setup(){
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CommodityDetails/");
	}
	
	@AfterTest
	public void teardown(){
		driver.quit();
	}

}
