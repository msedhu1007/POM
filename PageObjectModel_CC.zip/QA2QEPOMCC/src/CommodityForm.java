import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CommodityForm {

	public WebDriver driver;

	By txtName = By.id("name");
	By txtWeight = By.id("weight");
	By txtLength = By.id("length");
	By txtWidth = By.id("width");
	By txtHeight = By.id("height");
	By txtCount = By.cssSelector("input#count");
	By txtTotal = By.cssSelector("input#total");
	By btnAdd = By.id("add");
	String nameLocator = "(//table[@id='myTable']//td[1])[";
	String weightLocator = "(//table[@id='myTable']//td[2])[";
	String lengthLocator = "(//table[@id='myTable']//td[3])[";
	String widthLocator = "(//table[@id='myTable']//td[4])[";
	String heightLocator = "(//table[@id='myTable']//td[5])[";


	public CommodityForm(WebDriver driver){
		this.driver = driver;
	}
	

	public void setText(By object, String strValue){
		driver.findElement(object).clear();
		driver.findElement(object).sendKeys(strValue);
	}

	public void setCommodityDetails(String name,String weight, String lenght, String width, String height){
		setText(txtName, name);
		setText(txtWeight, weight);
		setText(txtLength, lenght);
		setText(txtWidth, width);
		setText(txtHeight, height);
		driver.findElement(btnAdd).click();
	}

	public String getNoofCommodity(){
		return driver.findElement(txtCount).getAttribute("value");
	}

	public String getTotalWeight(){
		return driver.findElement(txtTotal).getAttribute("value");
	}

	public String getName(int id){
		return driver.findElement(By.xpath(nameLocator+id+"]")).getText();
	}

	public String getWeight(int id){
		return driver.findElement(By.xpath(weightLocator+id+"]")).getText();
	}
	
	public String getLength(int id){
		return driver.findElement(By.xpath(lengthLocator+id+"]")).getText();
	}
	
	public String getWidth(int id){
		return driver.findElement(By.xpath(widthLocator+id+"]")).getText();
	}
	
	public String getHeight(int id){
		return driver.findElement(By.xpath(heightLocator+id+"]")).getText();
	}
}
