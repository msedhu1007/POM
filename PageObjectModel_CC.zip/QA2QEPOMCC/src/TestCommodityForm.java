import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCommodityForm extends DriverSetup{
	

	@Test(priority=1)
	void test_Commodity_Details(){
		CommodityForm objCF = new CommodityForm(driver);
		objCF.setCommodityDetails("LG 335 Refrigerator", "100", "450", "520", "1200");
		Assert.assertTrue(objCF.getName(2).equalsIgnoreCase("LG 335 Refrigerator"));
		Assert.assertTrue(objCF.getWeight(2).equalsIgnoreCase("100"));
		Assert.assertTrue(objCF.getLength(2).equalsIgnoreCase("450"));
		Assert.assertTrue(objCF.getWidth(2).equalsIgnoreCase("520"));
		Assert.assertTrue(objCF.getHeight(2).equalsIgnoreCase("1200"));
		Assert.assertTrue(objCF.getTotalWeight().equalsIgnoreCase("100"));		
		Assert.assertTrue(objCF.getNoofCommodity().equalsIgnoreCase("1"));
	}
	
	@Test(priority=2)
	void test_Commodity_DetailsAgain(){
		try {
			CommodityForm objCF = new CommodityForm(driver);
			objCF.setCommodityDetails("Leather Sofa Set", "120", "400", "800", "55");
			Thread.sleep(2000);
			Assert.assertTrue(objCF.getName(3).equalsIgnoreCase("Leather Sofa Set"));
			Assert.assertTrue(objCF.getWeight(3).equalsIgnoreCase("120"));
			Assert.assertTrue(objCF.getLength(3).equalsIgnoreCase("400"));
			Assert.assertTrue(objCF.getWidth(3).equalsIgnoreCase("800"));
			Assert.assertTrue(objCF.getHeight(3).equalsIgnoreCase("55"));
			Assert.assertTrue(objCF.getTotalWeight().equalsIgnoreCase("220"));
			Assert.assertTrue(objCF.getNoofCommodity().equalsIgnoreCase("2"));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
	}

}
