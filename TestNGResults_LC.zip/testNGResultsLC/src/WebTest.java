import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(ListenerTest.class)
public class WebTest {
	public WebDriver driver;
	By result = By.id("result");
	By txtName = By.id("nickname");
	By txtContactName = By.id("contact");
	By txtCompany = By.id("company");
	By txtCity = By.id("city");
	By txtCountry = By.id("country");
	By txtType = By.id("type");
	By btnAdd = By.id("add");
	By rdobtn = By.name("radio");
	By btnEdit = By.id("edit");
	By btnDelete = By.id("delete");

	String nickName = "Test User";
	String contactName = "Test";
	String company = "CTS";
	String city = "Indy";
	String country = "USA";
	String type = "value";
	
	private static Logger Log = Logger.getLogger(Log.class.getName());

	@BeforeMethod
	public void driverSetUp(){
		driver = new FirefoxDriver();
		Reporter.log("New driver instantiated");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/AddressBook/");
		Reporter.log("Web application launched");
		Log.info("Web Application launched");
	}

	@Test(priority=0)
	public void addAddressBook(){
		addAddBook(nickName, contactName, company, city, country, type);
	}

	@Test(priority=1) 
	public void updateAddressBook(){
		addAddressBook();
		isElementPresent(result);
		updateAddBook("User Test","","","Cognizant","","");
	}


	@Test(priority=2)
	public void deleteAddressBook(){
		addAddressBook();
		deleteAddBook();
	}

	@AfterMethod 
	public void teardown(){
		driver.quit();
	}

	public void setTxt(By locator, String value){
		driver.findElement(locator).clear();
		driver.findElement(locator).sendKeys(value);
		Reporter.log(value+" is entered in the field "+locator);
		Log.info(value+" is entered in the field "+locator);
	}

	public void click(By locator){
		driver.findElement(locator).click();
		Reporter.log(locator+" is clicked");
		Log.info(locator+" is clicked");
	}

	public void addAddBook(String nickname, String ContactName, String companyName, String city, String country, String type){
		setTxt(txtName, nickname);
		setTxt(txtContactName, ContactName);
		setTxt(txtCompany, companyName);
		setTxt(txtCity, city);
		setTxt(txtCountry, country);
		setTxt(txtType, type);
		click(btnAdd);
		sleep(2);
		Reporter.log("Address Book Added Sucessfully");
		Log.info("Address Book Added successfully");

	}

	public void updateAddBook(String name, String contactName, String company, String city, String country, String type){
		click(rdobtn);
		click(btnEdit);
		if(!name.isEmpty()){
			setTxt(txtName, name);
		}
		if(!contactName.isEmpty()){
			setTxt(txtContactName, contactName);
		}
		if(!company.isEmpty()){
			setTxt(txtCompany, company);
		}
		if(!city.isEmpty()){
			setTxt(txtCity, city);
		}
		if(!country.isEmpty()){
			setTxt(txtCountry, country);
		}
		if(!type.isEmpty()){
			setTxt(txtType, type);
		}
		click(btnAdd);
		Reporter.log("Address Book updated successfully");
		Log.info("Address Book updated successfully");

		sleep(2);
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public void sleep(int time){
		try{
			Thread.sleep(time*1000);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteAddBook(){
		click(rdobtn);
		click(btnDelete);
		Reporter.log("Address Book deleted successfully");
		Log.info("Address Book deleted successfully");
	}

}
