package test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	WebDriver driver;
	By txtUserName = By.name("username");
	By txtPassword = By.name("password");
	By btnLogin = By.name("login");
	
	public LoginPage(WebDriver driver){
		this.driver = driver;
	}
	
	public void setUserName(String strUserName){
		driver.findElement(txtUserName).clear();
		driver.findElement(txtUserName).sendKeys(strUserName);
	}
	
	public void setPassword(String strPassword){
		driver.findElement(txtPassword).clear();
		driver.findElement(txtPassword).sendKeys(strPassword);
	}

	public void clickLogin(){
		driver.findElement(btnLogin).click();
	}
	
	public boolean verifySignIn(String strUserName,String strPasword){
		setUserName(strUserName);
		setPassword(strPasword);
		clickLogin();
		return true;
	}
}
