package test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	WebDriver driver;
	By eleWelComeMsg = By.tagName("h2");
	By eleMyProfile = By.id("profile");

	public HomePage(WebDriver driver){
		this.driver = driver;
	}
	
	public String getWelcomeMessage(){
		return driver.findElement(eleWelComeMsg).getText();
	}
	
	public void clickMyProfile(){
		driver.findElement(eleMyProfile).click();
	}
	
	
}
