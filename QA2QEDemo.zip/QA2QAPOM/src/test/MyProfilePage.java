package test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class MyProfilePage {
	WebDriver driver;
	By txtName = By.xpath("//td[text()='Name']/following-sibling::td");
	By txtUserName = By.xpath("//td[text()='User Name']/following-sibling::td");
	By txtEmail = By.xpath("//td[text()='Email']/following-sibling::td");
	By txtRole = By.xpath("//td[text()='Role']/following-sibling::td");
	By txtAddress = By.xpath("//td[text()='Address']/following-sibling::td");
	By txtCity = By.xpath("//td[text()='City']/following-sibling::td");
	By txtState = By.xpath("//td[text()='State']/following-sibling::td");


	public MyProfilePage(WebDriver driver){
		this.driver = driver;
	}

	public String getName()	{
		return driver.findElement(txtName).getText();
	}


	public String getUsername()	{
		return driver.findElement(txtUserName).getText();	
	}

	public String getEmail(){
		return driver.findElement(txtEmail).getText();
	}

	public String getRole(){
		return driver.findElement(txtRole).getText();
	}

	public String getAddress(){
		return driver.findElement(txtAddress).getText();
	}

	public String getCity()	{
		return driver.findElement(txtCity).getText();

	}

	public String getState(){
		return driver.findElement(txtState).getText();

	}

	public boolean verifyMyProfile(){
		Assert.assertTrue(getName().equalsIgnoreCase("Robert"));		
		Assert.assertTrue(getUsername().equalsIgnoreCase("Admin"));		
		Assert.assertTrue(getEmail().equalsIgnoreCase("admin14@gmail.com"));		
		Assert.assertTrue(getRole().equalsIgnoreCase("Admin"));		
		Assert.assertTrue(getAddress().equalsIgnoreCase("981 Dundas St W"));		
		Assert.assertTrue(getCity().equalsIgnoreCase("Steelville"));		
		Assert.assertTrue(getState().equalsIgnoreCase("USA"));		
		return true;		
	}



}
