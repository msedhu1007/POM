package test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MyProfileTest {
	public WebDriver driver;
	private String strUsername = "Admin";
	private String strpwd = "admin123";

	@BeforeTest
	public void setup(){
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/Login_Servlet_3883/");
	}

	@Test
	public void testMyProfile()	{
		LoginPage objLP = new LoginPage(driver);
		objLP.verifySignIn(strUsername, strpwd);
		HomePage objHP = new HomePage(driver);
		objHP.clickMyProfile();
		MyProfilePage objMPP = new MyProfilePage(driver);
		Assert.assertTrue(objMPP.verifyMyProfile());
	}
	
	@AfterTest
	public void teardown(){
		driver.quit();
	}
}
